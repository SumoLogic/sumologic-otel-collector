typedef uint32_t Elf_Symndx;
